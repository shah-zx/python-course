from setuptools import setup 
setup(name = "packageharry" , version = "0.1" , description = "This is a code with shanu package" , long_description = "This is a very very long descripton : " ,author = "shahnawaz sayyed" , packages = ['packageshanu'] , install_requires = [])

